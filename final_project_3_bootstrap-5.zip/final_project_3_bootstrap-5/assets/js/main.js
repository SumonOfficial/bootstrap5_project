(function($){

    jQuery(document).ready(function(){

        // Magnific Popup Image
        $('.project-popup').magnificPopup({
            type: 'image',
            gallery:{
                enabled:true
            }
        });

    });

    jQuery(window).on('scroll', function(){
        
        if(jQuery(this).scrollTop() > 300){
            jQuery('.header-area').addClass('sticky');
        }else{
            jQuery('.header-area').removeClass('sticky');
        }
    });
   
    jQuery(document).ready(function(){

        jQuery(window).scroll(function(){

            var sumonIt = jQuery(window).scrollTop();

            if ( sumonIt > 400 ){
                jQuery('.scroll').fadeIn();
            }else{
                jQuery('.scroll').fadeOut();
            }
        })

        jQuery('.scroll').on('click', function(){

            jQuery('html, body').animate({'scrollTop' : 0}, 500);

        })
    })

    jQuery(document).ready(function(){

          // Slick Slider Active
          
        $('.testimonials').slick({
            slidesToShow: 1,
            dots: false,
            autoplay: true,
            autoplaySpeed: 2000,
            prevArrow: '<button type="button" class="slick-prev"><i class="fa-solid fa-arrow-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="fa-solid fa-arrow-right"></i></button>',
            responsive: [
                
                {
                  breakpoint: 768,
                  settings: {
                    slidesToShow: 1,
                    autoplay: true,
                    autoplaySpeed: 2000,
                    arrow: false,
                    dots: false
                  }
                },
                {
                  breakpoint: 480,
                  settings: {
                    dots: false,
                    autoplay: true,
                    autoplaySpeed: 2000,
                    slidesToShow: 1,
                    arrow: false
                  }
                }
              ]
        });
    });

    jQuery(document).ready(function(){
        // CounterUp Active
        $('.counter_up').counterUp();

    })

    jQuery(document).ready(function(){
        
        jQuery('#theme_burger').onePageNav();
    
    });
}(jQuery));
